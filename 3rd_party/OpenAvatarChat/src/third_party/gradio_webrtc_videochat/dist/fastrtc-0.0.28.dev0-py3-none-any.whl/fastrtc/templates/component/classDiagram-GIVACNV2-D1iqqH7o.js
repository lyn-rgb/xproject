import { s as r, c as s, a as e, C as t } from "./chunk-A2AXSNBT-v1Uq7rCF.js";
import { _ as l } from "./mermaid.core-CJIBE7t1.js";
var d = {
  parser: e,
  get db() {
    return new t();
  },
  renderer: s,
  styles: r,
  init: /* @__PURE__ */ l((a) => {
    a.class || (a.class = {}), a.class.arrowMarkerAbsolute = a.arrowMarkerAbsolute;
  }, "init")
};
export {
  d as diagram
};
