import { s as a, b as t, a as r, S as s } from "./chunk-AEK57VVT--f1Q258K.js";
import { _ as i } from "./mermaid.core-CJIBE7t1.js";
var _ = {
  parser: r,
  get db() {
    return new s(2);
  },
  renderer: t,
  styles: a,
  init: /* @__PURE__ */ i((e) => {
    e.state || (e.state = {}), e.state.arrowMarkerAbsolute = e.arrowMarkerAbsolute;
  }, "init")
};
export {
  _ as diagram
};
